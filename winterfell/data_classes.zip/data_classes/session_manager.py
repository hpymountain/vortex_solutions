class SessionManager:
    def __init__(self) -> None:
        pass